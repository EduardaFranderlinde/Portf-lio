package com.example.urna;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    EditText cpf, nCandidato;
    TextView nome, cargo, numeroC;
    int verificaBDCPF = 0;
    ArrayList<Candidato> listaCandidatos = new ArrayList<>();
    ArrayList<String> listaCPF = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        cpf = findViewById(R.id.cpf);
        nCandidato = findViewById(R.id.nCandidatos);
        nome = findViewById(R.id.nome);
        cargo = findViewById(R.id.cargo);
        numeroC = findViewById(R.id.numero);

        criaCandidatos();
    }

    public void criaCandidatos(){
        Candidato carlota = new Candidato("Carlota Pereira Silva", "Governadora", "66", 0);
        Candidato anelina = new Candidato("Anelina Canção", "Governadora", "99", 0);
        listaCandidatos.add(carlota);
        listaCandidatos.add(anelina);

        Candidato peralta = new Candidato("Carimbo Peralta", "Deputado Federal ", "1462", 0);
        Candidato barros = new Candidato("Xerox de Barros", "Deputado Federal ", "2882", 0);
        listaCandidatos.add(peralta);
        listaCandidatos.add(barros);

        Candidato zenia = new Candidato("Vó Zenia ", "Deputada Estadual", "33888", 0);
        Candidato tamia = new Candidato("Dona Tamia", "Deputada Estadual", "19500", 0);
        listaCandidatos.add(zenia);
        listaCandidatos.add(tamia);


        Candidato adatalberto = new Candidato("Adalberto Nunes", "Senador", "33888", 0);
        Candidato lidiano = new Candidato("Lidiano Casco-Duro", "Senadora", "12600", 0);
        listaCandidatos.add(adatalberto);
        listaCandidatos.add(lidiano);

        Candidato chaiane = new Candidato("Chaiane Abascal", "Presidente", "20", 0);
        Candidato melania = new Candidato("Melania Gogodeira", "Presidente", "15", 0);
        listaCandidatos.add(chaiane);
        listaCandidatos.add(melania);

    }

    public void verifica(View v){
        String  eleitor = cpf.getText().toString();
        String numero = nCandidato.getText().toString();

        for (Candidato c : listaCandidatos){
            if (numero.equals(c.numero)){
                nome.setText(c.getNome());
                cargo.setText(c.getCargo());
                numeroC.setText(c.getNumero());
            }else{
                Toast.makeText(MainActivity.this, "Este candidato não existe!", Toast.LENGTH_LONG).show();
            }
        }

    }

    public  void confirmar(View v){
        String numero = nCandidato.getText().toString();
        String numeroCadidato;

        for (Candidato c : listaCandidatos){
            if(cpf.getText().length() == 11 && numero.equals(c.numero)){
                salvarCPF();
                return;
            }else if(cpf.getText().length() < 11 || cpf.getText().length() > 11 ){

                Toast.makeText(MainActivity.this, "O formato do CPF deve ter somente números e ser igual a 11 caracteres", Toast.LENGTH_LONG).show();
            }else if(nCandidato.getText().toString() != null|| !numero.equals(c.numero)){
                Toast.makeText(MainActivity.this, "Escolha um candidato para votar!", Toast.LENGTH_LONG).show();
            }
        }

    }

    public void salvarCPF(){
        String cpfEleitor = cpf.getText().toString();

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                .child("Urna/Eleitores que já votaram");

            reference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if(snapshot.exists()){
                        ArrayList<String> cpfslist = new ArrayList<>();
                        String eleitoresBD = snapshot.getValue().toString();

                        eleitoresBD = eleitoresBD.replace("[", "");
                        eleitoresBD = eleitoresBD.replace("]", "");
                        cpfslist.add(eleitoresBD);

                        if (eleitoresBD.contains(cpfEleitor)){
                            Toast.makeText(MainActivity.this, "Este CPF já teve seu voto registrado!", Toast.LENGTH_LONG).show();

                        }else if(numeroC.getText().toString().equals(null)){
                            Toast.makeText(MainActivity.this, "Escolha um candidato para votar!", Toast.LENGTH_LONG).show();
                        }else{
                            cpfslist.add(cpfEleitor);

                          if(verificaBDCPF == 0){
                              mandaCPF(cpfslist);
                              contaVotos();
                              verificaBDCPF = verificaBDCPF +1;
                          }else if(verificaBDCPF == 1){
                              mandaCPF(listaCPF);
                              contaVotos();
                          }
                        }
                    }
                    else if(snapshot.exists() == false){
                        mandaCPF(listaCPF);
                        contaVotos();
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });

    }

    public void mandaCPF(ArrayList<String> lista){
        String cpfEleitor = cpf.getText().toString();
        listaCPF.add(cpfEleitor);
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                .child("Urna/Eleitores que já votaram");
        reference.setValue(lista);
    }

    public void contaVotos(){
        String numero = nCandidato.getText().toString();
        String cadidatoCargo = " ";
        String candidato = " ";



        for (Candidato c : listaCandidatos){
            if (numero.equals(c.numero)){
                cadidatoCargo =  c.getCargo().toLowerCase(Locale.ROOT);
                candidato = c.getNome();
            }
        }
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                .child("Urna/Contagem/"+cadidatoCargo+"/"+candidato);
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    int qtd = Integer.parseInt(dataSnapshot.getValue().toString());
                    qtd = qtd+1;

                    ContagemBD(qtd);

                }else{
                   int qtd=1;

                   ContagemBD(qtd);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public  void ContagemBD(int qtd){
        String numero = nCandidato.getText().toString();
        String cadidatoCargo = " ";
        String candidato = " ";


        for (Candidato c : listaCandidatos){
            if (numero.equals(c.numero)){
                cadidatoCargo =  c.getCargo().toLowerCase(Locale.ROOT);
                candidato = c.getNome();
            }
        }

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                .child("Urna/Contagem/"+cadidatoCargo+"/"+candidato);
        reference.setValue(qtd);

    }
}