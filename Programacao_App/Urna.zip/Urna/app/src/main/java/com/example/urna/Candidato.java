package com.example.urna;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class Candidato {
    String nome, cargo, numero;
    int quantifadeVotos;

    public Candidato(String nome, String cargo, String numero, int quantifadeVotos) {
        this.nome = nome;
        this.cargo = cargo;
        this.numero = numero;
        this.quantifadeVotos = quantifadeVotos;
    }

    public Candidato() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public int getQuantifadeVotos() {
        return quantifadeVotos;
    }

    public void setQuantifadeVotos(int quantifadeVotos) {
        this.quantifadeVotos = quantifadeVotos;
    }


}


